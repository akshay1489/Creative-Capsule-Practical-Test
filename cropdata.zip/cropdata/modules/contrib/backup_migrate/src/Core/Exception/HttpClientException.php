<?php

namespace Drupal\backup_migrate\Core\Exception;

/**
 *
 *
 * @package Drupal\backup_migrate\Core\Exception
 */
class HttpClientException extends BackupMigrateException {}
